import type { Context } from "hono";
import type { DeviceRow, Env, ModelWithProvider, ProviderType, TokenUsage } from "../types";
import { authenticateGateway } from "./auth";
import {
  findModelAndProvider,
  findModelCandidates,
  getModelWithProviderById,
  checkDeviceRateLimit,
  recordUsageSafe,
  randomRequestId,
  getSetting,
  getCurrentMonthSpend,
  getRecentProviderAvgLatencies,
  getDeviceMonthlyCost,
} from "../db/repo";
import { ensureSchema } from "../db/schema";
import { sendWebhookNotification } from "../utils/webhook";
import { parseUsage } from "./usage";
import { buildUpstreamHeaders, cleanResponseHeaders } from "../utils/http";
import { selectCandidateRoute } from "./routing";
import { parseRewriteRules, applyRequestRewriteRules } from "./rewrite";
import { inferModelCapabilities } from "./catalog";
import {
  convertResponsesRequest,
  convertChatToResponsesJson,
  createChatToResponsesTransform,
} from "./responses_adapter";
import {
  computeCacheKey,
  shouldBypassCache,
  getCachedEntry,
  setCachedEntry,
  createCachedResponse,
} from "./cache";

const DEFAULT_ENDPOINTS: Record<ProviderType, string> = {
  anthropic: "https://api.anthropic.com/v1",
  openai: "https://api.openai.com/v1",
  gemini: "https://generativelanguage.googleapis.com/v1beta/openai",
};

function waitUntil(c: Context<{ Bindings: Env }>, p: Promise<any>) {
  const ctx = (c as any).executionCtx as ExecutionContext | undefined;
  if (ctx?.waitUntil) ctx.waitUntil(p);
  else void p;
}

interface ProxyContext {
  c: Context<{ Bindings: Env }>;
  kind: "messages" | "chat/completions" | "responses";
  startedAt: number;
  device: DeviceRow;
  row: ModelWithProvider;
  upstreamStatus: number;
  latencyMs: number;
  requestId: string;
  createdAt: number;
  cacheKey?: string;
}

function buildTargetUrl(row: ModelWithProvider, kind: "messages" | "chat/completions" | "responses"): string {
  const base = (row.provider_endpoint || DEFAULT_ENDPOINTS[row.provider_type] || DEFAULT_ENDPOINTS.openai).replace(/\/+$/, "");
  const suffix = kind === "messages" ? "/messages" : kind === "responses" ? "/responses" : "/chat/completions";
  return base + suffix;
}

async function record(
  ctx: ProxyContext,
  usage: TokenUsage | null,
  statusCode: number
) {
  const inTokens = usage?.input_tokens ?? 0;
  const outTokens = usage?.output_tokens ?? 0;
  const inPrice = ctx.row.input_price_per_m || 0;
  const outPrice = ctx.row.output_price_per_m || 0;
  const costUsd = inPrice > 0 || outPrice > 0 ? (inTokens * inPrice + outTokens * outPrice) / 1_000_000 : 0;

  await recordUsageSafe(ctx.c.env, {
    device_id: ctx.device.id,
    provider_id: ctx.row.provider_id,
    provider_name: ctx.row.provider_name,
    model: ctx.row.model_name,
    usage,
    cost_usd: costUsd,
    cache_hit: 0,
    status_code: statusCode,
    latency_ms: ctx.latencyMs,
    request_id: ctx.requestId,
    created_at: ctx.createdAt,
  });
}

export function extractTextFromSse(kind: "messages" | "chat/completions", fullStreamText: string): string {
  let extractedText = "";
  const lines = fullStreamText.split(/\r?\n/);
  for (const line of lines) {
    if (!line.startsWith("data: ") || line.includes("[DONE]")) continue;
    try {
      const json = JSON.parse(line.slice(6));
      if (kind === "chat/completions") {
        const delta = json.choices?.[0]?.delta?.content;
        if (delta) extractedText += delta;
      } else if (kind === "messages") {
        if (json.type === "content_block_delta" && json.delta?.text) {
          extractedText += json.delta.text;
        }
      }
    } catch {}
  }
  return extractedText;
}

const MAX_TAIL_BYTES = 32 * 1024; // 32 KB tail for usage parsing
const MAX_CACHE_STREAM_BYTES = 512 * 1024; // 512 KB max for response caching

function passthroughStream(ctx: ProxyContext, upstreamRes: Response): Response {
  if (!upstreamRes.body) {
    const res = new Response(null, { status: upstreamRes.status, headers: cleanResponseHeaders(upstreamRes.headers) });
    waitUntil(ctx.c, record(ctx, null, upstreamRes.status));
    return res;
  }

  const shouldCache = upstreamRes.ok && Boolean(ctx.row.cache_enabled) && Boolean(ctx.cacheKey);
  let streamText = "";
  let headBuffer = "";
  let usageChunks = "";
  let cacheDisabledDueToSize = false;
  let resolveDone: () => void = () => {};
  const donePromise = new Promise<void>((resolve) => { resolveDone = resolve; });
  const decoder = new TextDecoder();

  const transform = new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk, controller) {
      const decoded = decoder.decode(chunk, { stream: true });

      // Capture head buffer for Anthropic message_start (up to MAX_TAIL_BYTES)
      if (headBuffer.length < MAX_TAIL_BYTES) {
        headBuffer += decoded;
      }

      // Capture any intermediate SSE lines mentioning usage/tokens
      if (decoded.includes("usage") || decoded.includes("tokens")) {
        usageChunks += decoded;
      }

      streamText += decoded;

      if (shouldCache && !cacheDisabledDueToSize) {
        if (streamText.length > MAX_CACHE_STREAM_BYTES) {
          // Stream exceeds cache limit; disable caching and keep only tail buffer
          cacheDisabledDueToSize = true;
          streamText = streamText.slice(-MAX_TAIL_BYTES);
        }
      } else {
        // Not caching; keep only tail buffer to prevent memory exhaustion
        if (streamText.length > MAX_TAIL_BYTES * 2) {
          streamText = streamText.slice(-MAX_TAIL_BYTES);
        }
      }

      controller.enqueue(chunk);
    },
    flush() {
      const finalChunk = decoder.decode();
      if (finalChunk) {
        streamText += finalChunk;
        if (headBuffer.length < MAX_TAIL_BYTES) headBuffer += finalChunk;
        if (finalChunk.includes("usage") || finalChunk.includes("tokens")) usageChunks += finalChunk;
      }
      resolveDone();
    },
  });

  const readable = upstreamRes.body.pipeThrough(transform);
  const headers = cleanResponseHeaders(upstreamRes.headers);
  const res = new Response(readable, { status: upstreamRes.status, headers });

  waitUntil(
    ctx.c,
    donePromise.then(async () => {
      const combinedUsageText = `${headBuffer}\n${usageChunks}\n${streamText}`;
      const usage = parseUsage(ctx.row.provider_type, combinedUsageText);
      await record(ctx, usage, upstreamRes.status);

      // Asynchronously cache on 200 OK if cache is enabled and within size limit
      if (shouldCache && !cacheDisabledDueToSize && ctx.cacheKey) {
        try {
          const extractedText = extractTextFromSse(ctx.kind as "messages" | "chat/completions", streamText);
          if (ctx.kind === "chat/completions") {
            const jsonBody = {
              id: `chatcmpl-${ctx.requestId}`,
              object: "chat.completion",
              created: Math.floor(ctx.createdAt / 1000),
              model: ctx.row.model_name,
              choices: [
                {
                  index: 0,
                  message: { role: "assistant", content: extractedText },
                  finish_reason: "stop",
                },
              ],
              usage: usage || { input_tokens: 0, output_tokens: 0, total_tokens: 0 },
            };
            await setCachedEntry(
              ctx.c.env,
              ctx.cacheKey,
              {
                kind: ctx.kind,
                model: ctx.row.model_name,
                jsonBody,
                usage: usage || { input_tokens: 0, output_tokens: 0, total_tokens: 0 },
                createdAt: ctx.createdAt,
              },
              ctx.row.cache_ttl
            );
          } else if (ctx.kind === "messages") {
            const jsonBody = {
              id: `msg_${ctx.requestId}`,
              type: "message",
              role: "assistant",
              model: ctx.row.model_name,
              content: [{ type: "text", text: extractedText }],
              stop_reason: "end_turn",
              usage: usage || { input_tokens: 0, output_tokens: 0, total_tokens: 0 },
            };
            await setCachedEntry(
              ctx.c.env,
              ctx.cacheKey,
              {
                kind: ctx.kind,
                model: ctx.row.model_name,
                jsonBody,
                usage: usage || { input_tokens: 0, output_tokens: 0, total_tokens: 0 },
                createdAt: ctx.createdAt,
              },
              ctx.row.cache_ttl
            );
          }
        } catch {}
      }
    })
  );
  return res;
}

async function executeProxyAttempt(
  c: Context<{ Bindings: Env }>,
  kind: "messages" | "chat/completions" | "responses",
  device: DeviceRow,
  row: ModelWithProvider,
  body: any,
  requestId: string,
  cacheKey?: string
): Promise<Response | null> {
  const upstreamKey =
    row.provider_api_key ||
    (row.provider_secret_name ? (c.env as Record<string, unknown>)[row.provider_secret_name] : undefined);
  if (typeof upstreamKey !== "string" || !upstreamKey) return null;

  const reqBody = { ...body, model: row.model_name };
  const isStream = reqBody.stream === true;
  const startedAt = Date.now();
  const headers = buildUpstreamHeaders(c.req.raw.headers, row.provider_type, upstreamKey);

  if (kind === "responses") {
    const target = buildTargetUrl(row, "chat/completions");
    let modelConfig: Record<string, any> | undefined;
    if (row.config_json) {
      try { modelConfig = JSON.parse(row.config_json); } catch {}
    }
    const chatBody = convertResponsesRequest(reqBody, modelConfig);
    headers.set("Content-Type", "application/json");

    const approxInputTokens = Math.max(1, Math.ceil(JSON.stringify(chatBody.messages).length / 4));

    let upstreamRes: Response;
    try {
      upstreamRes = await fetch(target, {
        method: "POST",
        headers,
        body: JSON.stringify(chatBody),
        redirect: "follow",
      });
    } catch {
      return null;
    }

    if (!upstreamRes.ok && (upstreamRes.status >= 500 || upstreamRes.status === 429)) {
      return null;
    }

    const pctx: ProxyContext = {
      c,
      kind,
      startedAt,
      device,
      row,
      upstreamStatus: upstreamRes.status,
      latencyMs: Date.now() - startedAt,
      requestId,
      createdAt: startedAt,
      cacheKey,
    };

    if (upstreamRes.ok) {
      if (isStream && upstreamRes.body) {
        let resolveDone: () => void = () => {};
        const donePromise = new Promise<void>((resolve) => { resolveDone = resolve; });
        let fullOutput = "";
        let fullMetadata: { reasoning?: string; outputItems?: any[] } | undefined;

        const transform = createChatToResponsesTransform(requestId, row.model_name, (text, meta) => {
          fullOutput = text;
          fullMetadata = meta;
          resolveDone();
        });

        const readable = upstreamRes.body.pipeThrough(transform);
        const outHeaders = cleanResponseHeaders(upstreamRes.headers);
        outHeaders.set("content-type", "text/event-stream; charset=utf-8");
        outHeaders.set("cache-control", "no-cache");

        waitUntil(
          c,
          donePromise.then(async () => {
            pctx.latencyMs = Date.now() - startedAt;
            const approxOutputTokens = Math.max(1, Math.ceil(fullOutput.length / 4));
            const usageObj = {
              input_tokens: approxInputTokens,
              output_tokens: approxOutputTokens,
              total_tokens: approxInputTokens + approxOutputTokens,
            };
            await record(pctx, usageObj, upstreamRes.status);

            if (row.cache_enabled && cacheKey) {
              const respJson = {
                id: `resp_${requestId}`,
                object: "response",
                status: "completed",
                model: row.model_name,
                output: fullMetadata?.outputItems || [
                  {
                    id: `item_${requestId}`,
                    type: "message",
                    role: "assistant",
                    status: "completed",
                    content: [{ type: "output_text", text: fullOutput }],
                  },
                ],
                usage: usageObj,
              };
              await setCachedEntry(
                c.env,
                cacheKey,
                {
                  kind,
                  model: row.model_name,
                  jsonBody: respJson,
                  usage: usageObj,
                  reasoning: fullMetadata?.reasoning,
                  createdAt: startedAt,
                },
                row.cache_ttl
              );
            }
          })
        );

        return new Response(readable, { status: 200, headers: outHeaders });
      } else {
        const chatJson: any = await upstreamRes.json();
        pctx.latencyMs = Date.now() - startedAt;
        const responsesJson = convertChatToResponsesJson(chatJson, requestId);
        const usage = chatJson.usage || {
          input_tokens: approxInputTokens,
          output_tokens: Math.max(1, Math.ceil((responsesJson.output?.[0]?.content?.[0]?.text || "").length / 4)),
          total_tokens: approxInputTokens + Math.max(1, Math.ceil((responsesJson.output?.[0]?.content?.[0]?.text || "").length / 4)),
        };
        waitUntil(
          c,
          record(pctx, usage, upstreamRes.status).then(async () => {
            if (row.cache_enabled && cacheKey) {
              const reasoning = chatJson.choices?.[0]?.message?.reasoning_content || undefined;
              await setCachedEntry(
                c.env,
                cacheKey,
                {
                  kind,
                  model: row.model_name,
                  jsonBody: responsesJson,
                  usage,
                  reasoning,
                  createdAt: startedAt,
                },
                row.cache_ttl
              );
            }
          })
        );
        return c.json(responsesJson, 200);
      }
    }

    const text = await upstreamRes.text();
    pctx.latencyMs = Date.now() - startedAt;
    const usage = parseUsage(row.provider_type, text);
    const res = new Response(text, {
      status: upstreamRes.status,
      headers: cleanResponseHeaders(upstreamRes.headers),
    });
    waitUntil(pctx.c, record(pctx, usage, upstreamRes.status));
    return res;
  }

  const target = buildTargetUrl(row, kind);
  let upstreamRes: Response;
  try {
    upstreamRes = await fetch(target, {
      method: "POST",
      headers,
      body: JSON.stringify(reqBody),
      redirect: "follow",
    });
  } catch {
    return null;
  }

  if (!upstreamRes.ok && (upstreamRes.status >= 500 || upstreamRes.status === 429)) {
    return null;
  }

  const pctx: ProxyContext = {
    c,
    kind,
    startedAt,
    device,
    row,
    upstreamStatus: upstreamRes.status,
    latencyMs: Date.now() - startedAt,
    requestId,
    createdAt: startedAt,
    cacheKey,
  };

  if (isStream) return passthroughStream(pctx, upstreamRes);

  const text = await upstreamRes.text();
  pctx.latencyMs = Date.now() - startedAt;
  const usage = parseUsage(row.provider_type, text);
  const res = new Response(text, {
    status: upstreamRes.status,
    headers: cleanResponseHeaders(upstreamRes.headers),
  });

  waitUntil(
    pctx.c,
    record(pctx, usage, upstreamRes.status).then(async () => {
      if (upstreamRes.ok && row.cache_enabled && cacheKey) {
        try {
          const jsonBody = JSON.parse(text);
          await setCachedEntry(
            c.env,
            cacheKey,
            {
              kind,
              model: row.model_name,
              jsonBody,
              usage: usage || { input_tokens: 0, output_tokens: 0, total_tokens: 0 },
              createdAt: startedAt,
            },
            row.cache_ttl
          );
        } catch {}
      }
    })
  );
  return res;
}

export async function handleGatewayProxy(c: Context<{ Bindings: Env }>, kind: "messages" | "chat/completions" | "responses") {
  const device = await authenticateGateway(c);
  if (!device) return c.json({ error: "unauthorized" }, 401);

  if (device.rate_limit_rpm && device.rate_limit_rpm > 0) {
    const allowed = await checkDeviceRateLimit(c.env, device.id, device.rate_limit_rpm);
    if (!allowed) {
      c.header("Retry-After", "60");
      return c.json(
        { error: "rate_limit_exceeded", message: `Device rate limit of ${device.rate_limit_rpm} RPM exceeded` },
        429
      );
    }
  }

  // Monthly Budget Check
  const budgetCfg = await getSetting<{ monthly_budget_usd: number; budget_action: "warn" | "block"; alert_threshold_pct: number }>(c.env, "budget_config");
  if (budgetCfg && budgetCfg.monthly_budget_usd > 0) {
    const currentSpend = await getCurrentMonthSpend(c.env);
    if (currentSpend >= budgetCfg.monthly_budget_usd) {
      if (budgetCfg.budget_action === "block") {
        waitUntil(
          c,
          sendWebhookNotification(c.env, {
            event: "budget_exceeded",
            title: "🚨【AI Gateway】月度预算已耗尽，已触发自动熔断拦截",
            message: `本月累计消耗 $${currentSpend.toFixed(2)}，已达到月度预算上限 $${budgetCfg.monthly_budget_usd.toFixed(2)}，后续代理请求已被拦截。`,
            details: {
              monthly_budget_usd: budgetCfg.monthly_budget_usd,
              current_spend_usd: currentSpend,
              action: "block",
            },
          })
        );
        return c.json(
          {
            error: "monthly_budget_exceeded",
            message: `Monthly budget limit of $${budgetCfg.monthly_budget_usd.toFixed(2)} has been reached ($${currentSpend.toFixed(2)} spent). Requests are blocked.`,
            spent_usd: currentSpend,
            budget_usd: budgetCfg.monthly_budget_usd,
          },
          429
        );
      }
    }
  }

  // Per-Device Monthly Spending Limit Check
  if (device.cost_limit_monthly && device.cost_limit_monthly > 0) {
    const deviceMonthSpend = await getDeviceMonthlyCost(c.env, device.id);
    if (deviceMonthSpend >= device.cost_limit_monthly) {
      waitUntil(
        c,
        sendWebhookNotification(c.env, {
          event: "device_budget_exceeded",
          title: `🚨【AI Gateway】设备「${device.name}」月度消费限额已达上限`,
          message: `设备「${device.name}」(ID: ${device.id}) 本月已消耗 $${deviceMonthSpend.toFixed(2)}，达到设定的设备月度限额 $${device.cost_limit_monthly.toFixed(2)}，后续请求已被自动拦截。`,
          details: {
            device_id: device.id,
            device_name: device.name,
            cost_limit_monthly: device.cost_limit_monthly,
            current_month_cost: deviceMonthSpend,
          },
        })
      );
      return c.json(
        {
          error: "device_budget_exceeded",
          message: `Device monthly spending limit of $${device.cost_limit_monthly.toFixed(2)} exceeded ($${deviceMonthSpend.toFixed(2)} spent). Requests are blocked.`,
          device_spent_usd: deviceMonthSpend,
          device_limit_usd: device.cost_limit_monthly,
        },
        429
      );
    }
  }

  const rawBody = await c.req.text();
  let body: any;
  try {
    body = JSON.parse(rawBody);
  } catch {
    return c.json({ error: "invalid_json" }, 400);
  }
  const modelKey = body?.model;
  if (typeof modelKey !== "string" || !modelKey) return c.json({ error: "missing_model" }, 400);

  // 1. Fetch all model candidates across providers
  const allCandidates = await findModelCandidates(c.env, modelKey);
  if (!allCandidates.length) return c.json({ error: "model_not_found", model: modelKey }, 404);

  // 2. Fetch recent provider latencies & sort candidates via dynamic routing engine
  const recentLatencies = await getRecentProviderAvgLatencies(c.env);
  const orderedCandidates = selectCandidateRoute(allCandidates, modelKey, recentLatencies);

  // 3. Filter candidates for protocol compatibility
  const compatibleCandidates = orderedCandidates.filter((cand) => {
    if (kind === "messages") return cand.provider_type === "anthropic";
    return cand.provider_type !== "anthropic";
  });

  if (!compatibleCandidates.length) {
    return c.json(
      {
        error: "unsupported_provider_for_path",
        message: kind === "messages"
          ? "/v1/messages requires an anthropic provider"
          : `/${kind} requires an openai or gemini provider`,
      },
      400
    );
  }

  let row = compatibleCandidates[0];

  // 4. Apply Request Rewrite Rules (System Prompt injection, parameter capping, model renaming)
  const rewriteRules = parseRewriteRules(row.config_json);
  body = applyRequestRewriteRules(body, rewriteRules, kind);

  const requestId = randomRequestId();
  const isStream = body?.stream === true;
  const bypass = shouldBypassCache(c.req.raw.headers, body);
  const cacheEnabled = Boolean(row.cache_enabled);

  let cacheKey: string | undefined;
  if (cacheEnabled) {
    cacheKey = await computeCacheKey(kind, row.model_name, body);

    if (!bypass) {
      const cached = await getCachedEntry(c.env, cacheKey);
      if (cached) {
        const cacheStartedAt = Date.now();
        const cachedRes = createCachedResponse(cached, kind, isStream, row.model_name, requestId);
        waitUntil(
          c,
          recordUsageSafe(c.env, {
            device_id: device.id,
            provider_id: row.provider_id,
            provider_name: row.provider_name,
            model: row.model_name,
            usage: cached.usage,
            cost_usd: 0,
            cache_hit: 1,
            status_code: 200,
            latency_ms: Date.now() - cacheStartedAt,
            request_id: requestId,
            created_at: cacheStartedAt,
          })
        );
        return cachedRes;
      }
    }
  }

  // 5. Primary candidate execution attempt
  let response = await executeProxyAttempt(c, kind, device, row, body, requestId, cacheKey);

  // 6. Failover across remaining compatible candidates
  if (!response && compatibleCandidates.length > 1) {
    for (let i = 1; i < compatibleCandidates.length; i++) {
      const nextCandidate = compatibleCandidates[i];
      const nextCacheKey = nextCandidate.cache_enabled
        ? await computeCacheKey(kind, nextCandidate.model_name, body)
        : undefined;
      response = await executeProxyAttempt(c, kind, device, nextCandidate, body, requestId, nextCacheKey);
      if (response) {
        row = nextCandidate; // Update effective provider row for reporting
        break;
      }
    }
  }

  // 7. If still failed and fallback_model_id is configured, attempt explicit fallback model
  if (!response && row.fallback_model_id) {
    const fallbackRow = await getModelWithProviderById(c.env, row.fallback_model_id);
    if (fallbackRow) {
      const isAnthropic = fallbackRow.provider_type === "anthropic";
      const isCompatible = (kind === "messages" && isAnthropic) || ((kind === "chat/completions" || kind === "responses") && !isAnthropic);
      if (isCompatible) {
        const fallbackCacheKey = fallbackRow.cache_enabled
          ? await computeCacheKey(kind, fallbackRow.model_name, body)
          : undefined;
        response = await executeProxyAttempt(c, kind, device, fallbackRow, body, requestId, fallbackCacheKey);
      }
    }
  }

  if (!response) {
    waitUntil(
      c,
      sendWebhookNotification(c.env, {
        event: "provider_error",
        title: `⚠️【AI Gateway】服务商请求异常 (${row.provider_name})`,
        message: `模型「${row.model_name}」主上游服务商 (${row.provider_name}) 请求失败且无法通过故障转移恢复。`,
        details: {
          model: row.model_name,
          provider: row.provider_name,
          requestId,
        },
      })
    );
    return c.json({ error: "upstream_service_unavailable", message: "Failed to fetch response from primary and fallback upstream" }, 502);
  }

  return response;
}

export async function listModelsHandler(c: Context<{ Bindings: Env }>) {
  await ensureSchema(c.env);
  const res = await c.env.DB.prepare(
    "SELECT m.id, m.model_name, m.display_name, m.alias, m.fallback_model_id, m.input_price_per_m, m.output_price_per_m, m.config_json, m.created_at, p.name as owned_by " +
      "FROM models m JOIN providers p ON p.id = m.provider_id " +
      "WHERE m.enabled = 1 AND p.enabled = 1 ORDER BY p.name, m.model_name"
  ).all();

  const data: any[] = [];
  const seenIds = new Set<string>();

  for (const r of (res.results || []) as any[]) {
    const created = r.created_at ? Math.floor(r.created_at / 1000) : 0;
    let customConfig: Record<string, any> = {};
    if (r.config_json) {
      try {
        customConfig = JSON.parse(r.config_json);
      } catch {}
    }
    const capabilities = Array.isArray(customConfig.capabilities) && customConfig.capabilities.length
      ? customConfig.capabilities
      : inferModelCapabilities(r.model_name);

    const makeEntry = (id: string) => ({
      id,
      object: "model",
      created,
      owned_by: r.owned_by || "system",
      permission: [
        {
          id: `modelperm-${id}`,
          object: "model_permission",
          created,
          allow_create_engine: false,
          allow_sampling: true,
          allow_logprobs: true,
          allow_search_indices: false,
          allow_view: true,
          allow_fine_tuning: false,
          organization: "*",
          group: null,
          is_blocking: false,
        },
      ],
      root: id,
      parent: null,
      display_name: r.display_name || null,
      alias: r.alias || null,
      fallback_model_id: r.fallback_model_id || null,
      input_price_per_m: r.input_price_per_m || 0,
      output_price_per_m: r.output_price_per_m || 0,
      capabilities,
    });

    if (r.model_name && !seenIds.has(r.model_name)) {
      seenIds.add(r.model_name);
      data.push(makeEntry(r.model_name));
    }
    if (r.alias && !seenIds.has(r.alias)) {
      seenIds.add(r.alias);
      data.push(makeEntry(r.alias));
    }
  }

  return c.json({ object: "list", data });
}

export async function getModelHandler(c: Context<{ Bindings: Env }>) {
  const modelId = c.req.param("model");
  if (!modelId) return c.json({ error: "model_not_found" }, 404);

  const row = await findModelAndProvider(c.env, modelId);
  if (!row) {
    return c.json(
      {
        error: {
          message: `The model '${modelId}' does not exist`,
          type: "invalid_request_error",
          param: "model",
          code: "model_not_found",
        },
      },
      404
    );
  }

  const created = row.created_at ? Math.floor(row.created_at / 1000) : 0;
  return c.json({
    id: modelId,
    object: "model",
    created,
    owned_by: row.provider_name || row.provider_type || "system",
    permission: [
      {
        id: `modelperm-${modelId}`,
        object: "model_permission",
        created,
        allow_create_engine: false,
        allow_sampling: true,
        allow_logprobs: true,
        allow_search_indices: false,
        allow_view: true,
        allow_fine_tuning: false,
        organization: "*",
        group: null,
        is_blocking: false,
      },
    ],
    root: modelId,
    parent: null,
    display_name: row.display_name || null,
    alias: row.alias || null,
    fallback_model_id: row.fallback_model_id || null,
    input_price_per_m: row.input_price_per_m || 0,
    output_price_per_m: row.output_price_per_m || 0,
  });
}

export async function listOllamaTagsHandler(c: Context<{ Bindings: Env }>) {
  await ensureSchema(c.env);
  const res = await c.env.DB.prepare(
    "SELECT m.id, m.model_name, m.display_name, m.alias, m.created_at, p.name as owned_by " +
      "FROM models m JOIN providers p ON p.id = m.provider_id " +
      "WHERE m.enabled = 1 AND p.enabled = 1 ORDER BY p.name, m.model_name"
  ).all();

  const models: any[] = [];
  const seen = new Set<string>();

  for (const r of (res.results || []) as any[]) {
    const names = [r.alias, r.model_name].filter(Boolean);
    for (const name of names) {
      if (seen.has(name)) continue;
      seen.add(name);
      models.push({
        name,
        model: name,
        modified_at: new Date(r.created_at || Date.now()).toISOString(),
        size: 0,
        digest: "sha256:0000000000000000000000000000000000000000000000000000000000000000",
        details: {
          format: "custom",
          family: r.owned_by || "ai",
          families: [r.owned_by || "ai"],
          parameter_size: "unknown",
          quantization_level: "none",
        },
      });
    }
  }

  return c.json({ models });
}

